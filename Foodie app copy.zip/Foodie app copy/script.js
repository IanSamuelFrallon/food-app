
document.addEventListener('DOMContentLoaded', function() {
  const signUpForm = document.getElementById('signUpForm');

  if (signUpForm) {
    signUpForm.addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent form from submitting

      const username = document.getElementById('username').value;
      const email = document.getElementById('email').value;
      const dob = document.getElementById('dob').value;
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;

      // Password validation
      if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
      }

      // Save user data in localStorage
      const user = {
        username: username,
        email: email,
        dob: dob,
        password: password
      };
      localStorage.setItem('user', JSON.stringify(user));

      // Redirect to login page
      alert('Sign-up successful! Redirecting to login page...');
      window.location.href = '/login/login.html';
    });
  }
});

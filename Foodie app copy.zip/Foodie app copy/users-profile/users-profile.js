function previewImage(event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      document.getElementById('profile-img').src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
}

const userData = JSON.parse(localStorage.getItem('user'));

// Populate user details on the profile page
if (userData) {
  document.getElementById('username').textContent = userData.username;
  document.getElementById('email').textContent = userData.email;
  document.getElementById('phone').textContent = userData.phone || ''; // Assume phone is in userData
  document.getElementById('description').textContent = userData.description || ''; // Assume description is in userData
}
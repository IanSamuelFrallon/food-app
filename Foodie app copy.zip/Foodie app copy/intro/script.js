function startBtn() {
   console.log("Get Started!")
}
(function() {
  function redirectToNoInternet() {
    if (!navigator.onLine && window.location.pathname !== '/no-internet/no-internet.html') {
      window.location.href = '/no-internet/no-internet.html';
    }
  }

  function checkInternetConnection() {
    if (navigator.onLine && window.location.pathname === '/no-internet/no-internet.html') {
      window.location.href = '/main-app/foodie-app.html';
    }
  }

  function tryAgain() {
    location.reload();
  }

  // Set an interval to check the connection periodically
  setInterval(checkInternetConnection, 5000);

  // Check connection status when the page loads
  window.addEventListener('load', redirectToNoInternet);
  window.addEventListener('online', checkInternetConnection);
  window.addEventListener('offline', redirectToNoInternet);

  // Export tryAgain function to be used in the no-internet.html file
  window.tryAgain = tryAgain;
})();
